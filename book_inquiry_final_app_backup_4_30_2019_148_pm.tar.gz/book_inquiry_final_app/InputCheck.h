#ifndef INPUTCHECK_H
#define INPUTCHECK_H

using namespace std;

class InputCheck{
  public:
    void checkInput(char &inVar, char reqIn1, char reqIn2, char reqIn3, char reqIn4);

  private:
    int count;
};
#endif //INPUTCHECK_H
